function J = J4D_FS(x,xb0,B0,T,Y,HH,Rsqrt_inv,tipo,gam,M)

xk = x;
J = .5*norm(B0*(xk-xb0))^2;
for k = 1:M
    
    y = Y(:,k);
    H = HH(k,:);
    J = J+.5*norm(Rsqrt_inv*(y-operador(H,xk,tipo,gam)))^2;
    xk = propagate_model(xk,T);
    
end

end