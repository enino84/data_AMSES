%Variables

global P n erro 

%N - number of model realizations
N = 20;

%n - number of model components
n = 40;

%m - number of observed components from model state
% dm = 2;
% H = 1:dm:n;
m = 40;%length(H);

%T - forecast step
T0 = [0 10]; %Ensemble initialization

Tf = [0 .01]; %Forecast step
TJ = 0:0.01:1; %Plot ensemble trajectories
T = Tf;

%P - model parameters
P.F = 8;

%Errors
errb = 0.05;
erro = 0.01;
R = erro^2*eye(m,m);
Rsqrt = sqrt(R);


%M - Assimilation steps
M = 15;

%Radio de influencia
r = 18;

%optipo = 1;

