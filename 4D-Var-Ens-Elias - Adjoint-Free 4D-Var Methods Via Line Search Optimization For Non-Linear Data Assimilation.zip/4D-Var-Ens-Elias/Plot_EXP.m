clc
clear all
close all

colorx=[0,0.4470, 0.7410];

tableN20=zeros(7,6);
tableN60=zeros(7,6);

Ns = [20,60]
gams=1:7
ps=[.7 1]
rs=[2,6,18]
yli = [-2.5 4;-2.5 4;2 3.6;2.7 3.7;2.7 3.7;2.7 3.7;2.7 3.7];
for iN=1:2
    for ip = 1:2
        for igam=1:7
            for ir=1:3
                N=Ns(iN);
                p=ps(ip);
                r=rs(ir);
                gam=gams(igam);
                
                filename=strcat('sim_r',num2str(r),'_N',num2str(N),'_p',num2str(p),'_gam',num2str(gam),'.mat');              
                TR = load(filename)
                nacomp = ['COM-N',num2str(N),'-p',num2str(p*100),'-r',num2str(r),'-gamma',num2str(gam)];
%                 fig = figure;
%                 hold all
%                 plot(log(errb)');
%                 plot(log(erra)');

                eb = TR.ERRb_freerun';
                eu = TR.ERRu';
                em = TR.ERRu_mlef';
                
                EB = log(TR.ERRb_freerun');
                EU = log(TR.ERRu');
                EM = log(TR.ERRu_mlef');
%                 mEB = mean(EB');
% 
%                 [~,ie] = sort(mEB);
% 
%                 EB = EB(ie(1:25),:);
%                 EC = EC(ie(1:25),:);

                mEB = mean(EB);
                stEB = std(EB);
                meb = mean(eb);
                steb = std(eb);

                mEU = mean(EU);
                stEU = std(EU);
                meu = mean(eu);
                steu = std(eu);
                
                mEM = mean(EM);
                stEM = std(EM);
                mem = mean(em);
                stem = std(em);

                pEB(1,:) = mEB+stEB;
                pEB(2,:) = mEB-stEB;

                pEU(1,:) = mEU+stEU;
                pEU(2,:) = mEU-stEU;
                
                pEM(1,:) = mEM+stEM;
                pEM(2,:) = mEM-stEM;

                x = 0:14;
                fig = figure;
                hold all
                X = [x,fliplr(x)];
                Y = [pEB(1,:),fliplr(pEB(2,:))];
                YC = [pEU(1,:),fliplr(pEU(2,:))];
                YQ = [pEM(1,:),fliplr(pEM(2,:))];
                
                fill(X,Y,'r');
                fill(X,YQ,'b');
                fill(X,YC,[0,0.4470, 0.7410]);
                alpha(.3)
                plot(x,mEB,'--ok','markersize',8,'markerfacecolor','r');
                plot(x,mEM,'--ok','markersize',8,'markerfacecolor','b');
                plot(x,mEU,'--ok','markersize',8,'markerfacecolor',[0,0.4470, 0.7410]);
              %  axis([0 25 -15 5]);
                xlim([0 14]);
                ylim([yli(igam,1) yli(igam,2)]);
                xl = xlabel('Assimilation Step ($\ell$)');
                set(xl,'fontsize',22,'interpreter','latex');
                yl = ylabel('$\log \left ( \left \| {\bf x}^a_{\ell} - {\bf x}_{\ell}^{*} \right \| \right )$');
                set(yl,'fontsize',22,'interpreter','latex');
             %   title(['$\gamma = ',num2str(gamma),'$'],'fontsize',20,'interpreter','latex');
                grid on
                le = legend('NODA','4D-MLEF','4D-EnKF-MC');
                set(le,'fontsize',16,'interpreter','latex','location','northoutside','orientation','horizontal');
                set(gca,'fontsize',22);
                
                set(gcf,'Units','inches');
                screenposition = get(gcf,'Position');
                set(gcf,...
                    'PaperPosition',[0 0 screenposition(3:4)],...
                    'PaperSize',[screenposition(3:4)]);

                print(fig,'-depsc',nacomp);
     
                if(N==20)
                    table20((igam-1)*3+1,(ir-1)*4+(ip-1)*2+1)=mean(meb);
                    table20((igam-1)*3+2,(ir-1)*4+(ip-1)*2+1)=mean(mem);
                    table20((igam-1)*3+3,(ir-1)*4+(ip-1)*2+1)=mean(meu);
                    table20((igam-1)*3+1,(ir-1)*4+(ip-1)*2+2)=mean(steb);
                    table20((igam-1)*3+2,(ir-1)*4+(ip-1)*2+2)=mean(stem);
                    table20((igam-1)*3+3,(ir-1)*4+(ip-1)*2+2)=mean(steu);
                elseif(N==60)
                    table60((igam-1)*3+1,(ir-1)*4+(ip-1)*2+1)=mean(meb);
                    table60((igam-1)*3+2,(ir-1)*4+(ip-1)*2+1)=mean(mem);
                    table60((igam-1)*3+3,(ir-1)*4+(ip-1)*2+1)=mean(meu);
                    table60((igam-1)*3+1,(ir-1)*4+(ip-1)*2+2)=mean(steb);
                    table60((igam-1)*3+2,(ir-1)*4+(ip-1)*2+2)=mean(stem);
                    table60((igam-1)*3+3,(ir-1)*4+(ip-1)*2+2)=mean(steu);
                end
                close all
            end
        end
    end
end
