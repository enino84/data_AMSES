%EnKF driver for Lorenz 96

clc
clear all
close all

rng(1);

warning off

Variables;

%for K = 10:10:40
ro(100) = .85;
ro(200) = .9;
ro(300) = .95;
s = '';
    p =1
        
   %  s = [s,'\multirow{84}{*}{',num2str(p*100),'\%} &']; 
        
    for gam = [1 2 3 5 6 7]
        
        s = [s,'\multirow{6}{*}{',num2str(gam),'} ']
        for N = [20 60]
            
            s = [s,'& \multirow{3}{*}{',num2str(N),'} & '];
                
             %for r = [2 6 18]
                file1 = ['sim_r',num2str(2),'_N',num2str(N),'_p',num2str(p),'_gam',num2str(gam),'.mat'];
                file2 = ['sim_r',num2str(6),'_N',num2str(N),'_p',num2str(p),'_gam',num2str(gam),'.mat'];
                file3 = ['sim_r',num2str(18),'_N',num2str(N),'_p',num2str(p),'_gam',num2str(gam),'.mat'];
                
%                rrr
             
                % disp(filename);
                
                l1 = load(file1);
                l2 = load(file2);
                l3 = load(file3);
                
       
                
                EB1 = l1.ERRu;
                EC1 = l1.ERRu_mlef;
                ED1 = l1.ERRb_freerun;
                mEB1 = mean(sqrt(mean(EB1.^2)));                
                mEC1 = mean(sqrt(mean(EC1.^2)));        
                mED1 = mean(sqrt(mean(ED1.^2)));  
                
                EB2 = l2.ERRu;
                EC2 = l2.ERRu_mlef;
                ED2 = l2.ERRb_freerun;
                mEB2 = mean(sqrt(mean(EB2.^2)));                
                mEC2 = mean(sqrt(mean(EC2.^2)));        
                mED2 = mean(sqrt(mean(ED2.^2)));  
                
                EB3 = l3.ERRu;
                EC3 = l3.ERRu_mlef;
                ED3 = l3.ERRb_freerun;
                mEB3 = mean(sqrt(mean(EB3.^2)));                
                mEC3 = mean(sqrt(mean(EC3.^2)));        
                mED3 = mean(sqrt(mean(ED3.^2)));  

            
                
                %  ee
                
                % & 230 & 35 \\ \cline{1-6}
                
                meb1 = sprintf('%1.3f', mEB1);
                mec1 = sprintf('%1.3f', mEC1);
                med1 = sprintf('%1.3f', mED1);
                meb2 = sprintf('%1.3f', mEB2);
                mec2 = sprintf('%1.3f', mEC2);
                med2 = sprintf('%1.3f', mED2);
                meb3 = sprintf('%1.3f', mEB3);
                mec3 = sprintf('%1.3f', mEC3);
                med3 = sprintf('%1.3f', mED3);
               

                
                
                if N == 20
                s = [s,'   2 & ',meb1,' & ',mec1,' & \multirow{6}{*}{',med1,'}  \\ \cline{3-5}'];
                else
                s = [s,'   2 & ',meb1,' & ',mec1,' &   \\ \cline{3-5}'];
                end
              %  s = [s,'  & 2 & ',meb1,' & ',mec1,' & \multirow{6}{*}{',med1,'} & \\ \cline{3-5}'];
                s = [s,' & & 6 & ',meb2,' & ',mec2,' &   \\ \cline{3-5}'];
                s = [s,' & & 18 & ',meb3,' & ',mec3,' &   \\ \cline{2-5}'];
%                 s = [s,'  & 6 & ',med,' & & & 30 & ',mbd,' & \\ \cline{3-4}\cline{7-8}'];
%                 s = [s,'  & 18 & ',mew,' & & & 40 & ',mbw,' & \\ \cline{2-4}\cline{6-8}']; %\cline{2-9}
                
                if N==60
                   s = [s,' \cline{1-6}'];
%                 else
%                     s = [s,'\cline{1-9}'];
                end
                
             end
        %end
%         eee
%         if gam<7
%             s = [s,'& '];
%         end
            
       % s = [s,' \cline{3-6} '];
              
    end
         

%end


%p = make_plots(chX,xb,xt,y,tipo,gam,XB,XA);


