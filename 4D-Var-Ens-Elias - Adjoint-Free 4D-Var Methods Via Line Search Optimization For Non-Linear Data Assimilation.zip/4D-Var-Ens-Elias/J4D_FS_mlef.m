function J = J4D_FS_mlef(alpha,xb0,DX,T,Y,HH,Rsqrt_inv,tipo,gam,M)
N=length(alpha);
J = (N-1)*norm(alpha)^2;
xk=xb0+DX*alpha;
for k = 1:M
    
    y = Y(:,k);
    H = HH(k,:);
    J = J+.5*norm(Rsqrt_inv*(y-operador(H,xk,tipo,gam)))^2;
    xk = propagate_model(xk,T);
    
end

end