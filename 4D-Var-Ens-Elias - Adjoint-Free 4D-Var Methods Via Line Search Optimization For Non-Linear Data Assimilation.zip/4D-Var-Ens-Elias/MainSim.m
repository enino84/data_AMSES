clc
clear all
close all

L = load('SampleLorenz.mat');

%Tfmax=[0.01 0.1 0.15 0.2];
Ns=[20 60];
ps=[0.7 1];
gammas=1:7;
rs=[18 6 2]; 

for i1=1:length(rs)
    for i2=1:length(Ns)
        for i3=1:length(ps)
            for i4=1:length(gammas)
                
                clear XUmc XUmc_mlef XBmc XBmc_freerun XTmc ERRb ERRu ERRu_mlef ERRb_freerun
                freerun=0;
                
                for mc=1:30
                    mc
                	clearvars -except L rs Ns ps gammas i1 i2 i3 i4 mc XUmc XUmc_mlef XBmc XTmc ERRb ERRu ERRu_mlef
                    Variables
                    N=Ns(i2)
                    p=ps(i3)
                    r=rs(i1)
                    gam=gammas(i4)
                    rng(mc)
                    MainBinv
                    XUmc(:,:,mc)=XU;
                    XUmc_mlef(:,:,mc)=XU_mlef;
                    XBmc(:,:,mc)=XB_k;
                    ERRb(:,mc)=errb;
                    ERRu(:,mc)=erru;
                    ERRu_mlef(:,mc)=erru_mlef;
                end
                
                filename=strcat('sim_r',num2str(r),'_N',num2str(N),'_p',num2str(p),'_gam',num2str(gam),'.mat');
                save(filename,'XUmc','XBmc','XT','ERRb','ERRu','ERRu_mlef','XT','N','r','p','gam','M')

            end
        end
	end
end

