%clc
%clear all
%close all

%rng(15);

%Variables

%L = load('SampleLorenz.mat');

%N = 60;
XB = L.XB(:,randperm(1000,N));
xt = L.xt;

if(freerun==0)
    xb0= L.xb0;
else
    xb0=  L.XB(:,randperm(1000,1));   
end

rng(mc)

tipo = 7; %No cambiar
%gam = 7;
%p = .7;
%Tf=[0 0.01]
m = round(p*n);
Rinv = (1/erro^2)*eye(m,m);
Rsqrt_inv = sqrt(Rinv);

for k = 1:M
    for e = 1:N
    	XB(:,e) = propagate_model(XB(:,e),Tf);
    end
    xbk = mean(XB,2);
    xt = propagate_model(xt,Tf);    
    H = randperm(n,m);
    y = operador(H,xt,tipo,gam) + erro*randn(m,1);
    DX = XB-xbk*ones(1,N);
    Bsqrt = B_inv(DX,r);

    if k == 1
       B0 = Bsqrt; 
    end

    Uk = inv(Bsqrt);
    XBk(:,:,k) = XB;
    Xm(:,k) = xbk;
    XT(:,k) = xt;
    Y(:,k) = y;
    U(:,:,k) = Uk;
    DXk(:,:,k)=DX;
    HH(k,:)=H;

end

errb=zeros(1,k);
xb_k=xb0;
for k=1:M
    XB_k(:,k)=xb_k;
    xt_k = XT(:,k);
    errb(k)=norm(xb_k-xt_k);
    xb_k=propagate_model(xb_k,Tf);
end



%hold all
%plot(log(errb),'r');


if(freerun==0)


%% Inicio
colplot='kbgymkbgymkkkkk';


%4DVAR
xb0 = Xm(:,1);
xu0 = Xm(:,1);
alphau=zeros(n,1);
for u = 1:10

A = eye(n,n);
d = -alphau;

    for k = 1:M
        if k==1
            XU(:,k) = xu0;
        else
            XU(:,k) = propagate_model(XU(:,k-1),Tf);    
        end
        Hk = HH(k,:);
        HL = jacobian(Hk,XU(:,k),tipo,gam);
        
        Uk = U(:,:,k);
        XB = XBk(:,:,k);
        xbk = mean(XB,2);
        
        
        Qk = HL*Uk;
        yk = Y(:,k);
        dk = yk-operador(Hk,XU(:,k),tipo,gam);
        A = A+Qk'*Rinv*Qk;
        d = d+Qk'*Rinv*dk;
        
    end

    w = A\d;
    
    U0 = Uk(:,:,1);
    dx0 = U0*w;

    [rho_opt,JK] = LS_3OPT_FS(0,1,xu0,xb0,dx0,B0,Rsqrt_inv,Y,tipo,HH,M,Tf,gam,50);
    xuc = xu0 + dx0;
    Ju0_b = J4D_FS(xb0,xb0,B0,Tf,Y,HH,Rsqrt_inv,tipo,gam,M);
    
    if norm(rho_opt*dx0) <= 1e-6
       break; 
    end
    
    xu0 = xu0 + rho_opt*dx0;
    Ju0_a = J4D_FS(xu0,xb0,B0,Tf,Y,HH,Rsqrt_inv,tipo,gam,M);

    alphau=alphau+rho_opt*w;
    
    %Ju(u) = Ju0_a
    %xb0 = xu0;

    %plot(log(erru),colplot(u));
    

    
end

erru=zeros(1,k);
xu_k=xu0;

for k=1:M
    XU(:,k)=xu_k;
    xt_k = XT(:,k);
    erru(k)=norm(xu_k-xt_k);
    xu_k = propagate_model(xu_k,Tf);
end



 % 4d var MLEF
xb0 = Xm(:,1);
xu0 = Xm(:,1);
alphau=zeros(N,1);

for u = 1:10

A_mlef = (N-1)*eye(N,N);
d_mlef = -alphau;

    for k = 1:M
        if k==1
            XU_mlef(:,k) = xu0;
        else
            XU_mlef(:,k) = propagate_model(XU_mlef(:,k-1),Tf);    
        end
        Hk = HH(k,:);
        HL = jacobian(Hk,XU(:,k),tipo,gam);
        
        DX=DXk(:,:,k);
        Qk_mlef=HL*DX;
        
        yk = Y(:,k);
        dk = yk-operador(Hk,XU(:,k),tipo,gam);
        
        A_mlef = A_mlef+Qk_mlef'*Rinv*Qk_mlef;
        d_mlef = d_mlef+Qk_mlef'*Rinv*dk;
        
    end

    w = A_mlef\d_mlef;
    
    DX0 = DXk(:,:,1);
    dx0 = DX0*w;

    [rho_opt,JK] = LS_3OPT_FS_mlef(0,1,alphau,xb0,w,DX0,Rsqrt_inv,Y,tipo,HH,M,Tf,gam,50);
    Ju0_b = J4D_FS_mlef(alphau*0,xb0,DX0,Tf,Y,HH,Rsqrt_inv,tipo,gam,M);
    
    if norm(rho_opt*w) <= 1e-6
       break; 
    end
    
    alphau=alphau+rho_opt*w;
    Ju0_a = J4D_FS_mlef(alphau,xb0,DX0,Tf,Y,HH,Rsqrt_inv,tipo,gam,M);

    xu0 = xu0 + DX0*alphau;
        
    Ju(u) = Ju0_a
  
    
end


erru_mlef=zeros(1,k);
xu_k=xu0;

for k=1:M
    XU_mlef(:,k)=xu_k;
    xt_k = XT(:,k);
    erru_mlef(k)=norm(xu_k-xt_k);
    xu_k = propagate_model(xu_k,Tf);
end       
        
end



