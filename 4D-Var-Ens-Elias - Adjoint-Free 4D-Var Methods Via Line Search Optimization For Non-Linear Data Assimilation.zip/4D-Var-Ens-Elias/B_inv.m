function [Bsqrt1,Bsqrt2] = B_inv(XB,r)

global n

L = eye(n,n);
D(1,1) = 1/var(XB(1,:));
for i = 2:n
    %Subdominio i
    ci = get_subdom(i,r,n);
    %Predecesors
    pi = ci(find(ci<i));
    if (~isempty(pi))
    yres = XB(i,:);
    X = XB(pi,:);
    bet = pinv(X*X',0.01)*(X*(yres'));
    L(i,pi) = -bet;
    D(i,i) = 1/var(yres'-X'*bet);
    end   
end

Bsqrt1 = L'*sqrt(D);%*L;
Bsqrt2 = sqrt(D)*L;
end