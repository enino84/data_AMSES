clc
clear all
close all


for gam = 1:6
   for r = [6,18]
      for N = [20,60]
         for p = [.7,1]
             fn = ['sim_r',num2str(r),...
                 '_N',num2str(N),'_p',num2str(p),...
                 '_gam',num2str(gam),'.mat'];
             P = load(fn);
             fig = figure;
             hold all
             title(fn);
             plot(log(P.ERRb),'-k','linewidth',5);
             plot(log(mean(P.ERRu_mlef')),'-g','linewidth',3);
             plot(log(mean(P.ERRu')),'-b','linewidth',3);
             
             grid on
            % eeee
         end
      end
   end
end