function [alp,F] = LS_3OPT_FS_mlef(a,b,alphau,xb0,w,DX0,Rsqrt_inv,Y,tipo,HH,M,Tf,gam,IT)
F = [];
for i = 1:IT
dialp = linspace(a,b,5);
alp1 = dialp(2); alpha1 = alphau+alp1*w;
alp2 = dialp(3); alpha2 = alphau+alp2*w;
alp3 = dialp(4); alpha3 = alphau+alp3*w;
%f1 = J4D_FS(x1,xb,xk,B,Rinv,y,optipo,H);
f1 = J4D_FS_mlef(alpha1,xb0,DX0,Tf,Y,HH,Rsqrt_inv,tipo,gam,M);
f2 = J4D_FS_mlef(alpha2,xb0,DX0,Tf,Y,HH,Rsqrt_inv,tipo,gam,M);
f3 = J4D_FS_mlef(alpha3,xb0,DX0,Tf,Y,HH,Rsqrt_inv,tipo,gam,M);
%f2 = J4D_FS(x2,xb,xk,B,Rinv,y,optipo,H);
%f3 = J4D_FS(x3,xb,xk,B,Rinv,y,optipo,H);
if f1 <= f2 && f1 <= f3
    b = alp2; alp=alp1; F = [F f1];
else
   if f2 <= f3 && f2 <= f1
    a = alp1; b = alp3; alp=alp2; F = [F f2];
else
    a = alp2; alp=alp3; F = [F f3];
end 
end
end

end