function c = get_subdom(i,r,n)
c = i-r:i+r;
c(find(c<1)) = c(find(c<1))+n;
c(find(c>n)) = c(find(c>n))-n;
end